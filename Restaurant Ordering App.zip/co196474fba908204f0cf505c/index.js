import { menuArray } from './data.js';

let cartArray = [];
let menuHTML = '';
let totalPrice= 0;
let paymentForm = document.getElementById('paymentModal')
let payButton = document.getElementById("pay")
let orderComplete = document.getElementById("orderSubmitted")







function getMenuHTML(){
    
    menuArray.forEach(function(item){
        menuHTML += `
        <div id="menu">
        <div class="menu-inner"> 
        
        <img src="${item.emoji}"class="item-graphic">
        </div>
        <div class="item-name"> ${item.name}
        </div>
        <div class="item-description"> ${item.ingredients}
        </div>
        <div class="item-price">$${item.price} 
        <div class ="menu-btns">
        <button class= "add-btn" data-add=${item.id}> + </button>
        </div> 
        
               
        `
})
    
 return menuHTML   
}

function render(){
    
    const menuFeed = document.getElementById ('menu')
    menuFeed.innerHTML = getMenuHTML()
}

render()

document.addEventListener('click', function(e) {
    if (e.target.dataset.add) {
        handleAddClick(e.target.dataset.add);
        sumItems(e.target.dataset.add)  
    } else if (e.target.dataset.remove) {
        handleRemoveClick(e.target.dataset.remove);
        
    }
});


function handleAddClick(menuItem){

let targetMenuObj = menuArray.filter(function(item) {
        
        return item.id == menuItem
    
})[0]
cartArray.push(targetMenuObj)
sumItems()
renderCart()


}

function sumItems() {
    totalPrice = 0
    cartArray.forEach(item => {
    totalPrice += item.price;
    });
}

function handleRemoveClick(removeItem) {
    cartArray.splice(removeItem);
    sumItems();
    renderCart();
}

function getCartHTML() {
    let cartHTML =   ``
    
   ;
    
    cartArray.forEach (function(item, index){
        
        cartHTML += `<div id="cart">
        
                <button class="remove-btn" data-remove="${index}">Remove</button> ${item.name}
                $${item.price}
                
                </div> `;   
                })
    
    
    
            cartHTML += `

     <div class="checkoutSection"> 
        
        <p> Total Price: ${totalPrice} </p>
        
        <button id="completeOrderBtn" data-complete="${totalPrice}"> Complete Order </button>
        
        </div>
        
        </div>
        `
return cartHTML;
    
}



function renderCart() {
    const cartFeed = document.getElementById('cart');
    cartFeed.innerHTML = getCartHTML();
}


document.addEventListener('click', function(e){
   if(e.target.dataset.complete){
       console.log(e.target.dataset.complete)
       paymentForm.style.display= 'inline'
   }
})

payButton.addEventListener('click', function(e){
    e.preventDefault(payButton)
    orderComplete.style.display = 'inline'

    
})



        

    















